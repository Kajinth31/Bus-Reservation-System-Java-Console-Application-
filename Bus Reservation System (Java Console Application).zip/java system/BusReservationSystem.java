import java.io.*;
import java.util.*;

class Customer {
    String name, mobileNumber, email, city;
    int age;

    public Customer(String name, String mobileNumber, String email, String city, int age) {
        this.name = name;
        this.mobileNumber = mobileNumber;
        this.email = email;
        this.city = city;
        this.age = age;
    }

    @Override
    public String toString() {
        return "Name: " + name + ", Mobile: " + mobileNumber + ", Email: " + email + ", City: " + city + ", Age: " + age;
    }
}

class Bus {
    String busNumber, startPoint, endPoint, startTime;
    int totalSeats, reservedSeats;
    double fare;

    public Bus(String busNumber, int totalSeats, String startPoint, String endPoint, String startTime, double fare) {
        this.busNumber = busNumber;
        this.totalSeats = totalSeats;
        this.reservedSeats = 0;  // Initially no seats are reserved
        this.startPoint = startPoint;
        this.endPoint = endPoint;
        this.startTime = startTime;
        this.fare = fare;
    }

    public boolean hasAvailableSeats() {
        return reservedSeats < totalSeats;  // Check if the reserved seats are less than total seats
    }

    public void reserveSeat() {
        reservedSeats++;  // Increment reserved seats when a new reservation is made
    }

    @Override
    public String toString() {
        return "Bus Number: " + busNumber + ", Route: " + startPoint + " to " + endPoint + ", Start Time: " + startTime + ", Fare: " + fare + ", Available Seats: " + (totalSeats - reservedSeats);
    }
}

class Reservation {
    String mobileNumber, busNumber;
    int seatNumber;

    public Reservation(String mobileNumber, String busNumber, int seatNumber) {
        this.mobileNumber = mobileNumber;
        this.busNumber = busNumber;
        this.seatNumber = seatNumber;
    }

    @Override
    public String toString() {
        return "Mobile: " + mobileNumber + ", Bus: " + busNumber + ", Seat: " + seatNumber;
    }
}

public class BusReservationSystem {
    static Stack<Customer> customers = new Stack<>();
    static List<Bus> buses = new ArrayList<>();
    static Queue<Reservation> reservationQueue = new LinkedList<>();
    static Queue<Customer> waitingList = new LinkedList<>();

    // File paths for persistence
    static String customerFile = "customers.txt";
    static String busFile = "buses.txt";
    static String reservationFile = "reservations.txt";
    static String waitingListFile = "waitingList.txt";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        loadData();

        while (true) {
            System.out.println("1. Register Customer");
            System.out.println("2. Register Bus");
            System.out.println("3. Reserve Seat");
            System.out.println("4. Cancel Reservation");
            System.out.println("5. Display Reservations");
            System.out.println("6. Display Buses");
            System.out.println("7. Display Waiting List");
            System.out.println("8. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    registerCustomer(scanner);
                    break;
                case 2:
                    registerBus(scanner);
                    break;
                case 3:
                    reserveSeat(scanner);
                    break;
                case 4:
                    cancelReservation(scanner);
                    break;
                case 5:
                    displayReservations();
                    break;
                case 6:
                    displayBuses();
                    break;
                case 7:
                    displayWaitingList();
                    break;
                case 8:
                    saveData();
                    System.out.println("Exiting system...");
                    return;
                default:
                    System.out.println("Invalid option. Try again.");
            }
        }
    }

    // Register a new customer
    public static void registerCustomer(Scanner scanner) {
        System.out.print("Enter name: ");
        String name = scanner.nextLine();
        System.out.print("Enter mobile number: ");
        String mobile = scanner.nextLine();
        System.out.print("Enter email: ");
        String email = scanner.nextLine();
        System.out.print("Enter city: ");
        String city = scanner.nextLine();
        System.out.print("Enter age: ");
        int age = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Customer customer = new Customer(name, mobile, email, city, age);
        customers.push(customer);
        System.out.println("Customer registered successfully!");
        saveCustomerData();
    }

    // Register a new bus
    public static void registerBus(Scanner scanner) {
        System.out.print("Enter bus number: ");
        String busNumber = scanner.nextLine();
        System.out.print("Enter total seats: ");
        int totalSeats = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter start point: ");
        String startPoint = scanner.nextLine();
        System.out.print("Enter end point: ");
        String endPoint = scanner.nextLine();
        System.out.print("Enter start time: ");
        String startTime = scanner.nextLine();
        System.out.print("Enter fare: ");
        double fare = scanner.nextDouble();
        scanner.nextLine(); // Consume newline

        Bus bus = new Bus(busNumber, totalSeats, startPoint, endPoint, startTime, fare);
        buses.add(bus);
        System.out.println("Bus registered successfully!");
        saveBusData();
    }

    // Reserve a seat for a customer
    public static void reserveSeat(Scanner scanner) {
        System.out.print("Enter customer mobile number: ");
        String mobile = scanner.nextLine();
        System.out.print("Enter start point: ");
        String startPoint = scanner.nextLine();
        System.out.print("Enter end point: ");
        String endPoint = scanner.nextLine();

        Customer customer = findCustomer(mobile);
        if (customer == null) {
            System.out.println("Customer not found!");
            return;
        }

        List<Bus> availableBuses = findAvailableBuses(startPoint, endPoint);
        if (availableBuses.isEmpty()) {
            System.out.println("No buses available on this route.");
            return;
        }

        System.out.println("Available buses:");
        for (int i = 0; i < availableBuses.size(); i++) {
            System.out.println(i + 1 + ". " + availableBuses.get(i));
        }

        System.out.print("Select bus number: ");
        int busIndex = scanner.nextInt() - 1;
        scanner.nextLine(); // Consume newline
        Bus selectedBus = availableBuses.get(busIndex);

        // Check if the bus has available seats
        if (!selectedBus.hasAvailableSeats()) {
            System.out.println("Sorry, no seats available. Adding you to the waiting list.");
            waitingList.add(customer);
            saveWaitingListData();
            return;
        }

        System.out.println("Available seats: ");
        for (int i = 1; i <= selectedBus.totalSeats; i++) {
            System.out.print(i + " ");
        }
        System.out.println();
        System.out.print("Choose seat number: ");
        int seatNumber = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Reservation reservation = new Reservation(mobile, selectedBus.busNumber, seatNumber);
        reservationQueue.add(reservation);
        selectedBus.reserveSeat(); // Increment reserved seats count for this bus
        System.out.println("Seat reserved successfully!");
        saveReservationData();
    }

    public static void saveData() {
        saveCustomerData();
        saveBusData();
        saveReservationData();
        saveWaitingListData();
    }

    // Cancel a reservation
    public static void cancelReservation(Scanner scanner) {
        System.out.print("Enter customer mobile number to cancel reservation: ");
        String mobile = scanner.nextLine();

        Reservation reservation = findReservation(mobile);
        if (reservation == null) {
            System.out.println("No reservation found for this customer.");
            return;
        }

        reservationQueue.remove(reservation);
        Bus bus = findBus(reservation.busNumber);
        if (bus != null) {
            bus.reservedSeats--; // Decrement reserved seats when reservation is canceled
        }
        System.out.println("Reservation canceled successfully!");

        if (!waitingList.isEmpty()) {
            Customer nextCustomer = waitingList.poll();
            System.out.println("Notifying waiting customer " + nextCustomer.name + " about available seat.");
            // Add seat reservation for the next customer
        }

        saveReservationData();
    }

    // Display all reservations
    public static void displayReservations() {
        if (reservationQueue.isEmpty()) {
            System.out.println("No reservations made yet.");
        } else {
            reservationQueue.forEach(System.out::println);
        }
    }

    // Display all buses
    public static void displayBuses() {
        if (buses.isEmpty()) {
            System.out.println("No buses registered.");
        } else {
            buses.forEach(System.out::println);
        }
    }

    // Display all waiting list customers
    public static void displayWaitingList() {
        if (waitingList.isEmpty()) {
            System.out.println("No customers in the waiting list.");
        } else {
            waitingList.forEach(System.out::println);
        }
    }

    // Load data from text files
    public static void loadData() {
        loadCustomerData();
        loadBusData();
        loadReservationData();
        loadWaitingListData();
    }

    // Load customer data from file
    public static void loadCustomerData() {
        try (BufferedReader reader = new BufferedReader(new FileReader(customerFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                customers.push(new Customer(data[0], data[1], data[2], data[3], Integer.parseInt(data[4])));
            }
        } catch (IOException e) {
            System.out.println("Error loading customer data.");
        }
    }

    // Load bus data from file
    public static void loadBusData() {
        try (BufferedReader reader = new BufferedReader(new FileReader(busFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                buses.add(new Bus(data[0], Integer.parseInt(data[1]), data[2], data[3], data[4], Double.parseDouble(data[5])));
            }
        } catch (IOException e) {
            System.out.println("Error loading bus data.");
        }
    }

    // Load reservation data from file
    public static void loadReservationData() {
        try (BufferedReader reader = new BufferedReader(new FileReader(reservationFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                reservationQueue.add(new Reservation(data[0], data[1], Integer.parseInt(data[2])));
            }
        } catch (IOException e) {
            System.out.println("Error loading reservation data.");
        }
    }

    // Load waiting list data from file
    public static void loadWaitingListData() {
        try (BufferedReader reader = new BufferedReader(new FileReader(waitingListFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                waitingList.add(new Customer(data[0], data[1], data[2], data[3], Integer.parseInt(data[4])));
            }
        } catch (IOException e) {
            System.out.println("Error loading waiting list data.");
        }
    }

    // Save customer data to file
    public static void saveCustomerData() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(customerFile))) {
            for (Customer customer : customers) {
                writer.write(customer.name + "," + customer.mobileNumber + "," + customer.email + "," + customer.city + "," + customer.age);
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error saving customer data.");
        }
    }

    // Save bus data to file
    public static void saveBusData() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(busFile))) {
            for (Bus bus : buses) {
                writer.write(bus.busNumber + "," + bus.totalSeats + "," + bus.startPoint + "," + bus.endPoint + "," + bus.startTime + "," + bus.fare);
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error saving bus data.");
        }
    }

    // Save reservation data to file
    public static void saveReservationData() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(reservationFile))) {
            for (Reservation reservation : reservationQueue) {
                writer.write(reservation.mobileNumber + "," + reservation.busNumber + "," + reservation.seatNumber);
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error saving reservation data.");
        }
    }

    // Save waiting list data to file
    public static void saveWaitingListData() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(waitingListFile))) {
            for (Customer customer : waitingList) {
                writer.write(customer.name + "," + customer.mobileNumber + "," + customer.email + "," + customer.city + "," + customer.age);
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error saving waiting list data.");
        }
    }

    // Find a customer by mobile number
    public static Customer findCustomer(String mobile) {
        return customers.stream().filter(customer -> customer.mobileNumber.equals(mobile)).findFirst().orElse(null);
    }

    // Find a bus by bus number
    public static Bus findBus(String busNumber) {
        return buses.stream().filter(bus -> bus.busNumber.equals(busNumber)).findFirst().orElse(null);
    }

    // Find a reservation by customer mobile number
    public static Reservation findReservation(String mobile) {
        return reservationQueue.stream().filter(reservation -> reservation.mobileNumber.equals(mobile)).findFirst().orElse(null);
    }

    // Find available buses based on start and end point
    public static List<Bus> findAvailableBuses(String startPoint, String endPoint) {
        List<Bus> availableBuses = new ArrayList<>();
        for (Bus bus : buses) {
            if (bus.startPoint.equalsIgnoreCase(startPoint) && bus.endPoint.equalsIgnoreCase(endPoint)) {
                availableBuses.add(bus);
            }
        }
        return availableBuses;
    }
}
